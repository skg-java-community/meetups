package com.example.graphqlserver.model;

public record Author(
        String id,
        String firstName,
        String lastName
) {
}