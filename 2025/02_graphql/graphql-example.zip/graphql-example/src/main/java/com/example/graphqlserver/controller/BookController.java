package com.example.graphqlserver.controller;

import com.example.graphqlserver.model.Author;
import com.example.graphqlserver.model.Book;
import com.example.graphqlserver.model.Review;
import com.example.graphqlserver.repository.AuthorRepository;
import com.example.graphqlserver.repository.BookRepository;
import com.example.graphqlserver.repository.ReviewRepository;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.graphql.data.method.annotation.SchemaMapping;
import org.springframework.stereotype.Controller;
import lombok.extern.java.Log;

import java.util.List;

@Controller
@Log
public class BookController {
    @QueryMapping
    public Book bookById(@Argument String id) {
        return BookRepository.getByBookId(id);
    }

    @QueryMapping
    public List<Book> books() {
        //log.info("Get all books");
        return BookRepository.all();
    }


    @SchemaMapping
    public Author author(Book book) {
        //log.info("Get author for book: " + book.id());
        return AuthorRepository.getByAuthorId(book.authorId());
    }


    @SchemaMapping (typeName = "Book", field = "reviews")
    public List<Review> getBookReviewsForBook(Book book) {
        //log.info("Get Book Reviews for Book: " + book.id());
        return ReviewRepository.getByBookId(book.id());
    }
}