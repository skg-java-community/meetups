package com.example.graphqlserver.repository;

import com.example.graphqlserver.model.Author;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class AuthorRepository {

    private static List<Author> authors = new ArrayList<>(Arrays.asList(
            new Author("author-1", "Joshua", "Bloch"),
            new Author("author-2", "Douglas", "Adams"),
            new Author("author-3", "Bill", "Bryson")
    ));

    public static Author getByAuthorId(String id) {
        return authors.stream()
                .filter(author -> author.id().equals(id))
                .findFirst()
                .orElse(null);
    }

    public static List<Author> all() {
        return authors;
    }












    public static Author createAuthor(Author author) {
        authors.add(author);
        return author;
    }

}
