package com.example.graphqlserver.controller;

import com.example.graphqlserver.model.Author;
import com.example.graphqlserver.model.Book;
import com.example.graphqlserver.repository.AuthorRepository;
import com.example.graphqlserver.repository.BookRepository;
import lombok.extern.java.Log;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.graphql.data.method.annotation.SchemaMapping;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
@Log
public class AuthorController {

    @QueryMapping
    public List<Author> authors() {
        log.info("Get all authors");
        return AuthorRepository.all();
    }

    @QueryMapping
    public Author authorById(@Argument String id) {
        log.info("Getting author for id: " + id);
        return AuthorRepository.getByAuthorId(id);
    }


    @SchemaMapping
    public List<Book> books(Author author) {
        log.info("Get all books for author: " + author.id());
        return BookRepository.getByAuthorId(author.id());
    }


    @MutationMapping
    public Author createAuthor(@Argument String id, @Argument String firstName, @Argument String lastName) {
        Author author = new Author(id, firstName, lastName);
        log.info("Creating author with id: " + author.id());
        return AuthorRepository.createAuthor(author);
    }

}