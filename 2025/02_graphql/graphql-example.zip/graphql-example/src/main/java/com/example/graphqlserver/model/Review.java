package com.example.graphqlserver.model;

public record Review(
        String username,
        String bookId,
        String comment,
        ReviewRating rating
) {

    public enum ReviewRating {Excellent, Great, good, Nah}
}