package com.example.graphqlserver.model;

public record Book(
        String id,
        String title,
        int pageCount,
        String authorId
) {

}
