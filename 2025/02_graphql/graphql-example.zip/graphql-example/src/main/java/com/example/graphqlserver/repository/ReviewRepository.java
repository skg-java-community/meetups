package com.example.graphqlserver.repository;

import com.example.graphqlserver.model.Review;

import java.util.Arrays;
import java.util.List;

public class ReviewRepository {
    private static final List<Review> reviews = Arrays.asList(
            new Review("John", "book-1", "Amazing book", Review.ReviewRating.Excellent),
            new Review("Sarah", "book-1", "Really Enjoyed it", Review.ReviewRating.Great),
            new Review("John", "book-2", "Did not like it", Review.ReviewRating.Nah)
    );

    public static List<Review> getByBookId(String bookId) {
        return reviews.stream()
                .filter(review -> review.bookId().equals(bookId))
                .toList();
    }
}
