package jug.thessaloniki.banking.socket.server;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;

import javax.net.ssl.SSLParameters;
import javax.net.ssl.SSLServerSocketFactory;
import javax.net.ssl.SSLSocket;

public class ALPNServer {

	public static void main(String[] args) throws IOException{
		
		System.setProperty("javax.net.ssl.keyStore", "C:/Users/Martin/sample.pfx");
		System.setProperty("javax.net.ssl.keyStorePassword", "sample");
		
		SSLServerSocketFactory ssf = (SSLServerSocketFactory) SSLServerSocketFactory.getDefault();
	    ServerSocket ss = ssf.createServerSocket(4444);
	    while (true) {
	      SSLSocket s = (SSLSocket) ss.accept();
	      SSLParameters params = s.getSSLParameters();
	      params.setApplicationProtocols(new String[] {"XMPP v1.1", "XMPP v1.2"});
	      s.setSSLParameters(params);
	      
	      BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream()));
	      String line = null;
	      PrintStream out = new PrintStream(s.getOutputStream());
	      while (((line = in.readLine()) != null)) {
	        System.out.println(line);
		    out.println("Hi, client");
	      }
	      in.close();
	      out.close();
	      s.close();
	    }
	    
	}
}
