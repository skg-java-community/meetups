module protocol.xmpp {
	requires java.logging;
	requires banking.server;
	provides jug.thessaloniki.banking.server.protocol.BankingProtocol with jug.thessaloniki.banking.protocol.xmpp.XMPPProtocol;
}