module banking.server {
	requires java.logging;
	exports jug.thessaloniki.banking.server.applications;
	exports jug.thessaloniki.banking.server.protocol;
	exports jug.thessaloniki.banking.server.services;
	exports jug.thessaloniki.banking.server.protocol.permissions;
	uses jug.thessaloniki.banking.server.applications.BankingApplication;
	uses jug.thessaloniki.banking.server.protocol.BankingProtocol;
}
