
build server module: 
cd D:\stuff\seminars\Thessaloniki_JUG\workspace
set PATH=D:\software\Java\jdk9_181\bin;%PATH%
mkdir modules\banking.server modules\protocol.fix modules\protocol.alpha modules\protocol.sip modules\protocol.xmpp modules\application.demo 

dir /s /B banking-server\src\main\java\jug\thessaloniki\*.java > sources.txt
javac -d modules\banking.server banking-server\src\main\java\module-info.java @sources.txt

dir /s /B fix-protocol\src\main\java\jug\thessaloniki\*.java > sources.txt
javac --module-path modules -d modules\fix.protocol fix-protocol\src\main\java\module-info.java @sources.txt

dir /s /B alpha-protocol\src\main\java\jug\thessaloniki\*.java > sources.txt
javac --module-path modules -d modules\alpha.protocol alpha-protocol\src\main\java\module-info.java @sources.txt

dir /s /B xmpp1.1-protocol\src\main\java\jug\thessaloniki\*.java > sources.txt
javac --module-path modules -d modules\xmpp.protocol xmpp1.1-protocol\src\main\java\module-info.java @sources.txt

dir /s /B sip-protocol\src\main\java\jug\thessaloniki\*.java > sources.txt
javac --module-path modules -d modules\sip.protocol sip-protocol\src\main\java\module-info.java @sources.txt

dir /s /B demo-application\src\main\java\jug\thessaloniki\*.java > sources.txt
javac --module-path modules -d modules\demo.application demo-application\src\main\java\module-info.java @sources.txt

java --module-path modules -m banking.server/jug.thessaloniki.banking.server.Server

