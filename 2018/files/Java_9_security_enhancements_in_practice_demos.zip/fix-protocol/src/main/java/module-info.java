module protocol.fix {
	requires java.logging;
	requires banking.server;
	provides jug.thessaloniki.banking.server.protocol.BankingProtocol with jug.thessaloniki.banking.protocol.fix.FixProtocol;
}