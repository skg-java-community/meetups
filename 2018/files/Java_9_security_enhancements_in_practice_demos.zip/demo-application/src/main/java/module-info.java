module application.demo {
	requires java.logging;
	requires banking.server;
	provides jug.thessaloniki.banking.server.applications.BankingApplication with jug.thessaloniki.banking.app.demo.DemoApplication;
}