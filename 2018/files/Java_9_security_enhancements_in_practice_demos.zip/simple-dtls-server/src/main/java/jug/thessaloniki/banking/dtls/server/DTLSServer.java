package jug.thessaloniki.banking.dtls.server;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.net.SocketTimeoutException;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;

import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLEngine;
import javax.net.ssl.SSLEngineResult;
import javax.net.ssl.SSLParameters;

public class DTLSServer {

	private static int MAX_HANDSHAKE_LOOPS = 60;
	private static int MAX_APP_READ_LOOPS = 10;

	private static ByteBuffer serverApp = ByteBuffer.wrap("Hi Client, I'm Server".getBytes());
	private static ByteBuffer clientApp = ByteBuffer.wrap("Hi Server, I'm Client".getBytes());

	public static SSLEngine createSSLEngine() throws Exception {
		SSLContext sslCtx = SSLContext.getInstance("DTLS");
		sslCtx.init(null, null, null);
		SSLEngine engine = sslCtx.createSSLEngine();

		SSLParameters params = engine.getSSLParameters();
		params.setMaximumPacketSize(1024);

		engine.setUseClientMode(false);
		engine.setSSLParameters(params);

		return engine;
	}

	// handshake
	static void handshake(SSLEngine engine, DatagramSocket socket, SocketAddress peerAddr) throws Exception {

		boolean endLoops = false;
		int loops = MAX_HANDSHAKE_LOOPS;
		engine.beginHandshake();
		while (!endLoops) {
			
			if (--loops < 0) {
				throw new RuntimeException("Too much loops to produce handshake packets");
			}

			SSLEngineResult.HandshakeStatus hs = engine.getHandshakeStatus();
			if (hs == SSLEngineResult.HandshakeStatus.NEED_UNWRAP
					|| hs == SSLEngineResult.HandshakeStatus.NEED_UNWRAP_AGAIN) {

				ByteBuffer iNet;
				ByteBuffer iApp;
				if (hs == SSLEngineResult.HandshakeStatus.NEED_UNWRAP) {
					// receive ClientHello request and other SSL/TLS records
					byte[] buf = new byte[1024];
					DatagramPacket packet = new DatagramPacket(buf, buf.length);
					try {
						socket.receive(packet);
					} catch (SocketTimeoutException ste) {
						List<DatagramPacket> packets = onReceiveTimeout(engine, peerAddr);
						for (DatagramPacket p : packets) {
							socket.send(p);
						}

						continue;
					}

					iNet = ByteBuffer.wrap(buf, 0, packet.getLength());
					iApp = ByteBuffer.allocate(1024);
				} else {
					iNet = ByteBuffer.allocate(0);
					iApp = ByteBuffer.allocate(1024);
				}

				SSLEngineResult r = engine.unwrap(iNet, iApp);
				SSLEngineResult.Status rs = r.getStatus();
				hs = r.getHandshakeStatus();
				if (rs == SSLEngineResult.Status.BUFFER_OVERFLOW) {
					// the client maximum fragment size config does not work?
					throw new Exception("Buffer overflow: " + "incorrect client maximum fragment size");
				} else if (rs == SSLEngineResult.Status.BUFFER_UNDERFLOW) {
					// bad packet, or the client maximum fragment size
					// config does not work?
					if (hs != SSLEngineResult.HandshakeStatus.NOT_HANDSHAKING) {
						throw new Exception("Buffer underflow: " + "incorrect client maximum fragment size");
					} // otherwise, ignore this packet
				} else if (rs == SSLEngineResult.Status.CLOSED) {
					endLoops = true;
				} // otherwise, SSLEngineResult.Status.OK:

				if (rs != SSLEngineResult.Status.OK) {
					continue;
				}
			} else if (hs == SSLEngineResult.HandshakeStatus.NEED_WRAP) {
				List<DatagramPacket> packets = produceHandshakePackets(engine, peerAddr);
				for (DatagramPacket p : packets) {
					socket.send(p);
				}
			} else if (hs == SSLEngineResult.HandshakeStatus.NEED_TASK) {
				runDelegatedTasks(engine);
			} else if (hs == SSLEngineResult.HandshakeStatus.NOT_HANDSHAKING) {
				// OK, time to do application data exchange.
				endLoops = true;
			} else if (hs == SSLEngineResult.HandshakeStatus.FINISHED) {
				endLoops = true;
			}
		}

		SSLEngineResult.HandshakeStatus hs = engine.getHandshakeStatus();
		if (hs != SSLEngineResult.HandshakeStatus.NOT_HANDSHAKING) {
			throw new Exception("Not ready for application data yet");
		}
	}

	// deliver application data
	static void deliverAppData(SSLEngine engine, DatagramSocket socket, ByteBuffer appData, SocketAddress peerAddr)
			throws Exception {

		// Note: have not consider the packet loses
		List<DatagramPacket> packets = produceApplicationPackets(engine, appData, peerAddr);
		appData.flip();
		for (DatagramPacket p : packets) {
			socket.send(p);
		}
	}

	// receive application data
	static void receiveAppData(SSLEngine engine, DatagramSocket socket, ByteBuffer expectedApp) throws Exception {

		byte[] buf = new byte[1024];
		DatagramPacket packet = new DatagramPacket(buf, buf.length);
		socket.receive(packet);
		ByteBuffer netBuffer = ByteBuffer.wrap(buf, 0, packet.getLength());
		ByteBuffer recBuffer = ByteBuffer.allocate(1024);
		SSLEngineResult rs = engine.unwrap(netBuffer, recBuffer);
		recBuffer.flip();
		if (recBuffer.remaining() != 0) {
			if (!recBuffer.equals(expectedApp)) {
				System.out.println("Engine status is " + rs);
				throw new Exception("Not the right application data");
			}
		}
	}

	// produce handshake packets
	static List<DatagramPacket> produceHandshakePackets(SSLEngine engine, SocketAddress socketAddr) throws Exception {

		List<DatagramPacket> packets = new ArrayList<>();
		boolean endLoops = false;
		int loops = MAX_HANDSHAKE_LOOPS;
		while (!endLoops) {

			if (--loops < 0) {
				throw new RuntimeException("Too much loops to produce handshake packets");
			}

			ByteBuffer oNet = ByteBuffer.allocate(32768);
			ByteBuffer oApp = ByteBuffer.allocate(0);
			SSLEngineResult r = engine.wrap(oApp, oNet);
			oNet.flip();

			SSLEngineResult.Status rs = r.getStatus();
			SSLEngineResult.HandshakeStatus hs = r.getHandshakeStatus();
			if (rs == SSLEngineResult.Status.BUFFER_OVERFLOW) {
				// the client maximum fragment size config does not work?
				throw new Exception("Buffer overflow: " + "incorrect server maximum fragment size");
			} else if (rs == SSLEngineResult.Status.BUFFER_UNDERFLOW) {
				// bad packet, or the client maximum fragment size
				// config does not work?
				if (hs != SSLEngineResult.HandshakeStatus.NOT_HANDSHAKING) {
					throw new Exception("Buffer underflow: " + "incorrect server maximum fragment size");
				} // otherwise, ignore this packet
			} else if (rs == SSLEngineResult.Status.CLOSED) {
				throw new Exception("SSLEngine has closed");
			} // otherwise, SSLEngineResult.Status.OK

			// SSLEngineResult.Status.OK:
			if (oNet.hasRemaining()) {
				byte[] ba = new byte[oNet.remaining()];
				oNet.get(ba);
				DatagramPacket packet = createHandshakePacket(ba, socketAddr);
				packets.add(packet);
			}
			boolean endInnerLoop = false;
			SSLEngineResult.HandshakeStatus nhs = hs;
			while (!endInnerLoop) {
				if (nhs == SSLEngineResult.HandshakeStatus.NEED_TASK) {
					runDelegatedTasks(engine);
					nhs = engine.getHandshakeStatus();
				} else if ((nhs == SSLEngineResult.HandshakeStatus.FINISHED)
						|| (nhs == SSLEngineResult.HandshakeStatus.NEED_UNWRAP)
						|| (nhs == SSLEngineResult.HandshakeStatus.NOT_HANDSHAKING)) {

					endInnerLoop = true;
					endLoops = true;
				} else if (nhs == SSLEngineResult.HandshakeStatus.NEED_WRAP) {
					endInnerLoop = true;
				}
			}
		}

		return packets;
	}

	static DatagramPacket createHandshakePacket(byte[] ba, SocketAddress socketAddr) {
		return new DatagramPacket(ba, ba.length, socketAddr);
	}

	// produce application packets
	static List<DatagramPacket> produceApplicationPackets(SSLEngine engine, ByteBuffer source, SocketAddress socketAddr)
			throws Exception {

		List<DatagramPacket> packets = new ArrayList<>();
		ByteBuffer appNet = ByteBuffer.allocate(32768);
		SSLEngineResult r = engine.wrap(source, appNet);
		appNet.flip();

		SSLEngineResult.Status rs = r.getStatus();
		if (rs == SSLEngineResult.Status.BUFFER_OVERFLOW) {
			// the client maximum fragment size config does not work?
			throw new Exception("Buffer overflow: " + "incorrect server maximum fragment size");
		} else if (rs == SSLEngineResult.Status.BUFFER_UNDERFLOW) {
			// unlikely
			throw new Exception("Buffer underflow during wraping");
		} else if (rs == SSLEngineResult.Status.CLOSED) {
			throw new Exception("SSLEngine has closed");
		} // otherwise, SSLEngineResult.Status.OK

		// SSLEngineResult.Status.OK:
		if (appNet.hasRemaining()) {
			byte[] ba = new byte[appNet.remaining()];
			appNet.get(ba);
			DatagramPacket packet = new DatagramPacket(ba, ba.length, socketAddr);
			packets.add(packet);
		}

		return packets;
	}

	// run delegated tasks
	static void runDelegatedTasks(SSLEngine engine) throws Exception {
		Runnable runnable;
		while ((runnable = engine.getDelegatedTask()) != null) {
			runnable.run();
		}

		SSLEngineResult.HandshakeStatus hs = engine.getHandshakeStatus();
		if (hs == SSLEngineResult.HandshakeStatus.NEED_TASK) {
			throw new Exception("handshake shouldn't need additional tasks");
		}
	}

	// retransmission if timeout
	static List<DatagramPacket> onReceiveTimeout(SSLEngine engine, SocketAddress socketAddr) throws Exception {

		SSLEngineResult.HandshakeStatus hs = engine.getHandshakeStatus();
		if (hs == SSLEngineResult.HandshakeStatus.NOT_HANDSHAKING) {
			return new ArrayList<DatagramPacket>();
		} else {
			// retransmission of handshake messages
			return produceHandshakePackets(engine, socketAddr);
		}
	}
	
	public static void main(String[] args) throws Exception {

		System.setProperty("javax.net.ssl.keyStore", "C:/Users/Martin/sample.pfx");
		System.setProperty("javax.net.ssl.keyStorePassword", "sample");
		
		DatagramSocket serverDatagramSocket = new DatagramSocket();
		InetSocketAddress serverSocketAddr = new InetSocketAddress(InetAddress.getLocalHost(),
				2000);
		
		DatagramSocket socket = serverDatagramSocket;
		socket.setSoTimeout(10000); // 10 second

		// create SSLEngine
		SSLEngine engine = createSSLEngine();
		
		// handshaking
		InetSocketAddress clientAddr = new InetSocketAddress(InetAddress.getLocalHost(), 3000);
		handshake(engine, socket, clientAddr);
		
		// read client application data
		receiveAppData(engine, socket, clientApp);

		// write server application data
		deliverAppData(engine, socket, serverApp, clientAddr);
		
		socket.close();
	}
}
