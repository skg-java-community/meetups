package samples;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLServerSocket;
import javax.net.ssl.SSLSocket;

public class HttpsUrlConnectionExample {

	public static void main(String[] args) {
		
//		HttpsURLConnection connection = HttpsURLConnection.
	}
}
