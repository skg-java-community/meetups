package samples;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import javax.net.ssl.SSLServerSocket;
import javax.net.ssl.SSLServerSocketFactory;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocket;

public class ALPNCustomResultionExample {

	public static void main(String[] args) throws IOException {

		// Code for creating a server side SSLSocket
		SSLServerSocketFactory sslssf = (SSLServerSocketFactory) SSLServerSocketFactory.getDefault();
		SSLServerSocket sslServerSocket = (SSLServerSocket) sslssf.createServerSocket(9999);
		SSLSocket sslSocket = (SSLSocket) sslServerSocket.accept();

		// Code to set up a callback function
		// Pass in the current SSLSocket to be inspected and client AP values
		sslSocket.setHandshakeApplicationProtocolSelector((serverSocket, clientProtocols) -> {
			SSLSession handshakeSession = serverSocket.getHandshakeSession();
			String cipher = handshakeSession.getCipherSuite();
			int packetBufferSize = handshakeSession.getPacketBufferSize();
			if("RC4".equals(cipher) && packetBufferSize > 1024) {
				return "protocol1";
			} else {
				return "protocol2";
			}
		});

		sslSocket.startHandshake();

		// After the handshake, get the application protocol that has been
		// returned from the callback method.

		String ap = sslSocket.getApplicationProtocol();
		System.out.println("Application Protocol server side: \"" + ap + "\"");

		// Continue with the work of the server
		InputStream sslIS = sslSocket.getInputStream();
		OutputStream sslOS = sslSocket.getOutputStream();
		sslIS.read();
		sslOS.write(85);
		sslOS.flush();
		sslSocket.close();
	}
}
