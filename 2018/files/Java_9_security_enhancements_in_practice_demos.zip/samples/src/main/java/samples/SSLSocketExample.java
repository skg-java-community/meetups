package samples;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;

import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;

public class SSLSocketExample {
	
	public static void main(String[] args) throws UnknownHostException, IOException {
		
		System.setProperty("javax.net.ssl.trustStore", "C:/Users/Martin/sample.pfx");
		System.setProperty("javax.net.ssl.trustStorePassword", "sample");
		
		SSLSocketFactory ssf = (SSLSocketFactory) SSLSocketFactory.getDefault();
	    Socket s = ssf.createSocket("127.0.0.1", 4444);
	    PrintWriter out = new PrintWriter(s.getOutputStream(), true);
	    out.println("Hi, server.");
	    BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream()));
	    String x = in.readLine();
	    System.out.println(x);
	    out.close();
	    in.close();
	    s.close();
	}
	
}
